function t = ddddot(varargin)

t = product(4, varargin{:});
