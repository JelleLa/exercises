function t = dddot(varargin)

t = product(3, varargin{:});
