function [ bool ] = ne ( A , B )



if ~(A==B)
    bool = 1;
else
    bool = 0;
end


end

