function t = vertcat(varargin)

t = cat(1, varargin{:});
