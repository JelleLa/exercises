function n = ndims(t)

n = length(t.size);
