function t = uminus(t1)

t = t1;
t.components = -t1.components;
    
