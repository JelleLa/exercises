function t = horzcat(varargin)

t = cat(2, varargin{:});
