% -------------------------------------------------------------------------
% 4DB00 Dynamics and control of mechanical systems 2019-2020
% Crane challenge.
% -------------------------------------------------------------------------
clc;close all;clearvars
addpath Toolbox 
addpath Toolbox/Functions

%% Symbols
% Define the degrees of freedom and their first two derivative w.r.t. time
% as symbolic expressions
syms phi1 phi2 x1 dphi1 dphi2 dx1 ddphi1 ddphi2 ddx1   

% Define the system parameters, actuator force and time 
% as symbolic expressions
syms g L0 L1 L2 L m0 m1 m2 m3 kh dW dh    
syms FA                                                
syms t                  

% Place degrees of freedom (and their derivatives) in the generalized
% coordinates and the prescribed displacements.
Components.q        = [x1; phi2];
Components.dq       = [dx1; dphi2];
Components.ddq      = [ddx1; ddphi2];
Components.s_pd     = [phi1];
Components.ds_pd    = [dphi1];
Components.dds_pd   = [ddphi1];
Components.F        = [FA];
Components.time     = [t];

% Define system parameters as symbols
Components.parameters.g.symbol  = g;
Components.parameters.L0.symbol = L0;
Components.parameters.L1.symbol = L1;
Components.parameters.L2.symbol = L2;
Components.parameters.m0.symbol = m0;
Components.parameters.m1.symbol = m1;
Components.parameters.m2.symbol = m2;
Components.parameters.m3.symbol = m3;
Components.parameters.kh.symbol = kh;
Components.parameters.dW.symbol = dW;
Components.parameters.dh.symbol = dh;

%% ------------------------------------------------------------------------
%--------------------------------------------------------------------------
%--------> Please complete the following code for Deliverable 1:
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

% Insert the system parameter values:
Components.parameters.g.value  = [];    %m/(s^2)
Components.parameters.L0.value = [];    %m
Components.parameters.L1.value = [];    %m
Components.parameters.L2.value = [];    %m
Components.parameters.m0.value = [];    %kg
Components.parameters.m1.value = [];    %kg
Components.parameters.m2.value = [];    %kg
Components.parameters.m3.value = [];    %kg
Components.parameters.kh.value = [];    %N/m
Components.parameters.dW.value = [];    %N*s/(rad*m)
Components.parameters.dh.value = [];    %N*s/m

% Insert symbolic expressions for the kinetic and potential energy 
% and the generalized forces:
T   = [];   % Kinetic energy
V   = [];   % Potential energy
Qnc = [];   % Generalised forces

% Calculate the non-linear equations of motion (statement is complete):
Nonlinear_EOM = DOMS('NonlinearEOM',Components,T,V,Qnc);

% Insert the settings for the simulation:
t_sim     = [];  % Simulation time
q_init    = [];  % Initial value for q
dq_init   = [];  % Initial value for dq
s_pd_of_t = [];  % Prescribed displacement a function of time t (e.g. sin(t))
FA_of_t   = [];  % External force as a function of time t (e.g. cos(t))

% Simulate the non-linear equations of motion (statement is complete):
Sim_Nonlinear = DOMS('Sim_Nonlinear',Components, Nonlinear_EOM,...
                                   t_sim,q_init,dq_init,s_pd_of_t,FA_of_t);

% Simulate the virtual test setup in Simulink (statement is complete):
Sim_Setup  = DOMS('Sim_Setup',Components,t_sim,...
                                   q_init,dq_init,s_pd_of_t,FA_of_t);

%--------------------------------------------------------------------------
%--------> Please generate the plots for questions e and f here:
%--------------------------------------------------------------------------


return % This statement stops the script here.
       % Remove comment it, if you wish to continue with deliverable 2
%% ------------------------------------------------------------------------
%--------------------------------------------------------------------------
%--------> Please complete the following code for Deliverable 2:
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------

%Insert the linearization points
q_0_stable   = [];    %Stable equilibrium for linearization
q_0_unstable = [];    %Unstable equilibrium for linearization

% Linearize the equations of motion (statements are complete):
LinearEOM_stable   = DOMS('Linearize',Components,Nonlinear_EOM,q_0_stable);  
LinearEOM_unstable = DOMS('Linearize',Components,Nonlinear_EOM,q_0_unstable);  

% Insert the settings for the simulation:
t_sim             = [];   % Simulation time
q1_init_stable    = [];   % Initial value for q1
q1_init_unstable  = [];   % Initial value for q1
dq1_init_stable   = [];   % Initial value for dq1
dq1_init_unstable = [];   % Initial value for dq1
FA_of_t           = [];   % External force as a function of time t (e.g. cos(t))


% Simulate the linear equations of motion (statements are complete):
Sim_Linear_stable   = DOMS('Sim_Linear',Components,LinearEOM_stable,...
                            t_sim,q1_init_stable,dq1_init_stable, FA_of_t);
Sim_Linear_unstable = DOMS('Sim_Linear',Components,LinearEOM_unstable,...
                        t_sim,q1_init_unstable,dq1_init_unstable, FA_of_t);

%--------------------------------------------------------------------------
%--------> Please generate the plots for questions d and e here:
%--------------------------------------------------------------------------


