clearvars;clc;close all
load testfile_sims_par.mat
syms t1;
s = tf('s');
addpath Functions
sim('Crane_Simulink');
clearvars
disp("Your version of Matlab is ready for the crane challenge.")